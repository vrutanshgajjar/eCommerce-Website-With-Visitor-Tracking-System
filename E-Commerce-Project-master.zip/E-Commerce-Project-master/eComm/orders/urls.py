from django.urls import path


app_name = 'order'

urlpatterns = [
    # path('checkout/', order_checkout, name="checkout"),
]

